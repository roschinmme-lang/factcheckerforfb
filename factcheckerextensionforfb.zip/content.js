// 1. Inject Floating Action Button & Menu
const fab = document.createElement('button');
fab.className = 'fc-ext-fab';
fab.innerHTML = '🔍';
document.body.appendChild(fab);
// The New Menu Structure
const menu = document.createElement('div');
menu.className = 'fc-ext-menu';
menu.innerHTML = `
  <div id="fc-step-1">
    <div class="fc-ext-menu-title">What do you want to check?</div>
    <button class="fc-ext-menu-btn" id="fc-btn-factcheck">Fact Check Post</button>
    <button class="fc-ext-menu-btn" id="fc-btn-aidetection">Check for AI</button>
    <button class="fc-ext-menu-btn" id="fc-btn-theme" style="margin-top: 10px;">Dark Mode</button>
  </div>
  <div id="fc-step-2" class="fc-step-hidden">
    <div class="fc-ext-menu-title">How do you want to input?</div>
    <button class="fc-ext-menu-btn" id="fc-btn-snip">Snip Screen</button>
    <button class="fc-ext-menu-btn" id="fc-btn-upload">Upload File</button>
    <input type="file" id="fc-hidden-upload" accept="image/*" style="display:none;">
    <button class="fc-ext-menu-btn" id="fc-btn-back" style="background:transparent; color:#0866FF; justify-content:center;">⬅ Back</button>
  </div>
`;
document.body.appendChild(menu);
let overlay = null;
let selection = null;
let startX = 0, startY = 0;
let isDragging = false;
let currentMode = null; // Will be 'factcheck' or 'aidetection'
// Toggle menu visibility
fab.addEventListener('click', () => {
  menu.classList.toggle('show');
  resetMenu(); // Always open on Step 1
});
// Step 1 Click Listeners
document.getElementById('fc-btn-factcheck').addEventListener('click', () => setMode('factcheck'));
document.getElementById('fc-btn-aidetection').addEventListener('click', () => setMode('aidetection'));
function setMode(mode) {
  currentMode = mode;
  document.getElementById('fc-step-1').classList.add('fc-step-hidden');
  document.getElementById('fc-step-2').classList.remove('fc-step-hidden');
}
// Back Button
document.getElementById('fc-btn-back').addEventListener('click', resetMenu);
function resetMenu() {
  document.getElementById('fc-step-1').classList.remove('fc-step-hidden');
  document.getElementById('fc-step-2').classList.add('fc-step-hidden');
}
// Step 2 Click Listeners: SNIP
document.getElementById('fc-btn-snip').addEventListener('click', () => {
  menu.classList.remove('show'); // Hide menu
  if (overlay) return;
  overlay = document.createElement('div');
  overlay.className = 'fc-ext-overlay';
  document.body.appendChild(overlay);
  overlay.addEventListener('mousedown', startSnip);
  overlay.addEventListener('mousemove', dragSnip);
  overlay.addEventListener('mouseup', endSnip);
});
// Step 2 Click Listeners: UPLOAD
document.getElementById('fc-btn-upload').addEventListener('click', () => {
  document.getElementById('fc-hidden-upload').click();
});
document.getElementById('fc-hidden-upload').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (file) {
    menu.classList.remove('show'); // Hide menu
    const reader = new FileReader();
    reader.onload = (event) => {
      const base64Data = event.target.result.split(',')[1];
      showSpinner();
      chrome.runtime.sendMessage({
        action: "processManualUpload",
        base64: base64Data,
        mode: currentMode // Send the chosen mode!
      });
    };
    reader.readAsDataURL(file);
  }
});
function startSnip(e) {
  isDragging = true;
  startX = e.clientX;
  startY = e.clientY;
  selection = document.createElement('div');
  selection.className = 'fc-ext-selection';
  selection.style.left = `${startX}px`;
  selection.style.top = `${startY}px`;
  overlay.appendChild(selection);
}
function dragSnip(e) {
  if (!isDragging) return;
  const currentX = e.clientX;
  const currentY = e.clientY;
  const width = Math.abs(currentX - startX);
  const height = Math.abs(currentY - startY);
  selection.style.width = `${width}px`;
  selection.style.height = `${height}px`;
  selection.style.left = `${Math.min(currentX, startX)}px`;
  selection.style.top = `${Math.min(currentY, startY)}px`;
}
function endSnip(e) {
  isDragging = false;
  const rect = {
    x: Math.min(e.clientX, startX),
    y: Math.min(e.clientY, startY),
    w: Math.abs(e.clientX - startX),
    h: Math.abs(e.clientY - startY)
  };
  overlay.remove();
  overlay = null;
  showSpinner();
  setTimeout(() => {
    chrome.runtime.sendMessage({
      action: "captureAndAnalyze",
      rect: rect,
      dpr: window.devicePixelRatio,
      mode: currentMode // Send the chosen mode!
    });
  }, 100);
}
// ... Keep your existing showModal and other UI helpers below this point ...
// Note: You can remove the manual upload button from inside the modal HTML now, since it's on the main menu.
// 3. UI Helpers
let spinner = null;
function showSpinner() {
  spinner = document.createElement('div');
  spinner.className = 'fc-ext-spinner';
  document.body.appendChild(spinner);
}
function removeSpinner() {
  if (spinner) {
    spinner.remove();
    spinner = null;
  }
}
function showModal(result) {
  removeSpinner();
  const existingModal = document.querySelector('.fc-ext-modal');
  if (existingModal) existingModal.remove();
  const modal = document.createElement('div');
  modal.className = 'fc-ext-modal';
  // Apply fixed sizing to the modal container
  Object.assign(modal.style, {
    width: '450px',
    maxHeight: '80vh', // Caps height at 80% of the screen
    display: 'flex',
    flexDirection: 'column',
    padding: '20px',
    boxSizing: 'border-box'
  });
  let verdict = result.verdict || "Unknown";
  let explanation = result.explanation || "";
  if (typeof explanation === 'object') explanation = flattenObjectToText(explanation);
  const badgeClass = typeof verdict === 'string' ? verdict.toLowerCase().replace(/[^a-z]/g, '') : 'unknown'; 
  modal.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center; border-bottom: 1px solid var(--border-color); padding-bottom: 10px; margin-bottom: 15px; flex-shrink: 0;">
      <h3 style="margin:0; font-family: sans-serif; font-size: 18px; color: var(--text-main);">Fact Check Result</h3>
      <button id="fc-close-modal" style="background:none; border:none; font-size:28px; cursor:pointer; color:var(--text-main); line-height:1;">&times;</button>
    </div>
    <div style="overflow-y: auto; flex-grow: 1; padding-right: 8px; scrollbar-width: thin;">
      <div class="fc-ext-badge ${badgeClass}" style="margin-bottom: 12px; flex-shrink: 0;">
        ${verdict.toUpperCase()}
      </div>
      <p style="margin:0; font-family: sans-serif; font-size: 14px; line-height: 1.6; color: var(--text-main); white-space: pre-wrap;">
        ${explanation}
      </p>
    </div>
  `;
  document.body.appendChild(modal);
  document.getElementById('fc-close-modal').onclick = () => {
    modal.remove();
  };
}
/**
 * HELPER: Turns a nested JSON object into a readable paragraph
 */
function flattenObjectToText(obj) {
  let text = "";
  for (let key in obj) {
    if (typeof obj[key] === 'object') {
      text += flattenObjectToText(obj[key]) + " "; // Recursive call for nested parts
    } else {
      // Don't add the key name if it's just a generic index, just the value
      text += obj[key] + " ";
    }
  }
  return text.trim();
}
// 4. Message Listener
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "showResult") {
    // Pass the raw data directly to showModal, which now handles object unpacking safely
    showModal(message.data);
  }
});
// --- DARK MODE LOGIC ---
// 1. Listen for clicks on the theme button safely
document.addEventListener('click', (e) => {
  if (e.target && e.target.id === 'fc-btn-theme') {
    const isDark = document.body.classList.toggle('fc-dark-theme');
    e.target.innerHTML = isDark ? 'Light Mode' : 'Dark Mode';
    chrome.storage.local.set({ theme: isDark ? 'dark' : 'light' });
  }
});
// 2. Load saved theme when page opens
chrome.storage.local.get('theme', (data) => {
  if (data.theme === 'dark') {
    document.body.classList.add('fc-dark-theme');
    // Wait a tiny bit for the menu to exist, then change button text
    setTimeout(() => {
      const btn = document.getElementById('fc-btn-theme');
      if (btn) btn.innerHTML = 'Light Mode';
    }, 200);
  }
});