/**
 * FB FACT CHECKER - BACKGROUND SERVICE WORKER
 * Handles Snipping, Uploading, Fact Checking, and AI Detection.
 */
const MISTRAL_API_KEY = "FEjqwCAyv6BQKrszGIbJIw4CqNtHUM4g";
const MISTRAL_URL = "https://api.mistral.ai/v1/chat/completions";
// 1. Listen for messages from content.js
chrome.runtime.onMessage.addListener((message, sender) => {
  // Handle Snipping Tool captures
  if (message.action === "captureAndAnalyze") {
    chrome.tabs.captureVisibleTab(null, { format: "png" }, (dataUrl) => {
      if (chrome.runtime.lastError || !dataUrl) {
        chrome.tabs.sendMessage(sender.tab.id, {
          action: "showResult",
          data: { verdict: "Error", explanation: "Chrome capture failed. Refresh the page." }
        });
        return;
      }
      processMistral(dataUrl, message.rect, message.dpr, sender.tab.id, message.mode);
    });
  }
  // Handle Manual File Uploads
  if (message.action === "processManualUpload") {
    processMistralDirect(message.base64, sender.tab.id, message.mode);
  }
  return true;
});
// 2. Helper: Give Mistral the right instructions based on user choice
function getMistralPrompt(mode) {
  if (mode === "aidetection") {
    return "Analyze this image. 1) Is it an AI-generated image or a real photograph? Look for artifacts, weird textures, or inconsistencies. Respond ONLY in flat JSON with three keys: 'verdict' (use 'Likely AI' or 'Likely Real'), 'isAI' (use 'AI Check'), and 'explanation' (your reasoning).";
  } else {
    // Default Fact Check
    return "Fact check this image. 1) Is it True, Fake, or Misleading? 2) Is it AI-generated or a real photo? Respond ONLY in flat JSON with three keys: 'verdict' (True, Fake, or Misleading), 'isAI' (Likely AI or Likely Human), and 'explanation'.";
  }
}
// 3. Process Snipped Images (Requires Cropping)
async function processMistral(dataUrl, rect, dpr, tabId, mode) {
  try {
    const response = await fetch(dataUrl);
    const blob = await response.blob();
    const bitmap = await createImageBitmap(blob);
    const width = Math.max(1, rect.w * dpr);
    const height = Math.max(1, rect.h * dpr);
    const canvas = new OffscreenCanvas(width, height);
    const ctx = canvas.getContext('2d');
    ctx.drawImage(bitmap, rect.x * dpr, rect.y * dpr, rect.w * dpr, rect.h * dpr, 0, 0, width, height);
    const croppedBlob = await canvas.convertToBlob({ type: "image/jpeg", quality: 0.8 });
    const base64Data = await new Promise(r => {
      const reader = new FileReader();
      reader.onloadend = () => r(reader.result.split(',')[1]);
      reader.readAsDataURL(croppedBlob);
    });
    await sendToMistral(base64Data, tabId, mode);
  } catch (err) {
    console.error("Cropping Error:", err);
    chrome.tabs.sendMessage(tabId, { action: "showResult", data: { verdict: "Error", explanation: err.message } });
  }
}
// 4. Process Uploaded Images (Direct to AI)
async function processMistralDirect(base64Data, tabId, mode) {
    await sendToMistral(base64Data, tabId, mode);
}
// 5. The actual API Call to Mistral
async function sendToMistral(base64Data, tabId, mode) {
  try {
    const aiInstructions = getMistralPrompt(mode);
    const aiRes = await fetch(MISTRAL_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${MISTRAL_API_KEY}`
      },
      body: JSON.stringify({
        model: "pixtral-12b-2409",
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: aiInstructions },
              { type: "image_url", image_url: `data:image/jpeg;base64,${base64Data}` }
            ]
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0
      })
    });
    const data = await aiRes.json();
    if (data.error) throw new Error(data.error.message);
    let aiContent = data.choices[0].message.content;
    aiContent = aiContent.replace(/```json|```/gi, '').trim(); // Clean markdown
    let result = JSON.parse(aiContent);
    // Safety check in case Mistral nests the result
    if (result.fact_check) result = result.fact_check;
    if (result.result) result = result.result;
    chrome.tabs.sendMessage(tabId, { action: "showResult", data: result });
  } catch (err) {
    console.error("Mistral API Error:", err);
    chrome.tabs.sendMessage(tabId, {
      action: "showResult",
      data: { verdict: "Image cannot be process", explanation: err.message }
    });
  }
}